package com.example.autoresearch

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.net.http.SslError
import android.widget.*
import android.graphics.Color
import android.text.InputType
import android.util.TypedValue
import java.net.URI

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var urlsInput: EditText
    private lateinit var secondsInput: EditText
    private lateinit var timeoutInput: EditText
    private lateinit var statusText: TextView
    private lateinit var progressText: TextView
    private lateinit var currentText: TextView
    private lateinit var timerText: TextView
    private lateinit var queueText: TextView
    private lateinit var webView: WebView

    private var urls: List<String> = emptyList()
    private val statuses = mutableListOf<String>()
    private var index = 0
    private var secondsPerSite = 20
    private var loadTimeoutSeconds = 45
    private var secondsLeft = 20
    private var state = State.IDLE
    private var pageTimerStarted = false

    private enum class State { IDLE, READY, LOADING, RUNNING, PAUSED, STOPPED, DONE }

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (state != State.RUNNING) return
            secondsLeft--
            updateUi()
            if (secondsLeft <= 0) {
                statuses[index] = "Done"
                index++
                loadCurrent()
            } else handler.postDelayed(this, 1000L)
        }
    }

    private val loadTimeoutRunnable = Runnable {
        if (state == State.LOADING && index in urls.indices) {
            statuses[index] = "Failed"
            Toast.makeText(this, "लोडिंग टाइमआउट: अगली वेबसाइट पर जा रहे हैं", Toast.LENGTH_SHORT).show()
            index++
            loadCurrent()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        configureWebView()
        updateUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 13f, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }

    private fun button(text: String, action: () -> Unit) =
        Button(this).apply {
            this.text = text
            textSize = 12f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(43, 94, 190))
            setOnClickListener { action() }
        }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(8))
            setBackgroundColor(Color.rgb(11, 18, 32))
        }
        root.addView(label("WEB FLOW", 12f, true))
        root.addView(label("Automatic Website Queue", 24f, true))
        root.addView(label("हर लाइन में एक URL डालें। पेज लोड होने के बाद टाइमर शुरू होगा।"))

        urlsInput = EditText(this).apply {
            hint = "https://example.com\nhttps://wikipedia.org"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            textSize = 13f
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            minLines = 3
            maxLines = 5
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(24, 38, 60))
        }
        root.addView(urlsInput, LinearLayout.LayoutParams(-1, dp(112)).apply { topMargin = dp(8) })

        val settings = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val timeCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        timeCol.addView(label("प्रति वेबसाइट (सेकंड)"))
        secondsInput = numberInput("20")
        timeCol.addView(secondsInput, LinearLayout.LayoutParams(-1, dp(44)))
        settings.addView(timeCol, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })

        val timeoutCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        timeoutCol.addView(label("लोडिंग टाइमआउट"))
        timeoutInput = numberInput("45")
        timeoutCol.addView(timeoutInput, LinearLayout.LayoutParams(-1, dp(44)))
        settings.addView(timeoutCol, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(settings)

        root.addView(button("लिंक तैयार करें") { prepareQueue() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })

        statusText = label("स्थिति: तैयार नहीं", 14f, true)
        progressText = label("प्रगति: 0 / 0")
        currentText = label("वर्तमान: —", 12f)
        timerText = label("समय: —", 20f, true)
        queueText = label("Queue खाली है", 11f)
        root.addView(statusText)
        root.addView(progressText)
        root.addView(currentText)
        root.addView(timerText)

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            button("Start") { startResearch() },
            button("Pause") { pauseResearch() },
            button("Resume") { resumeResearch() },
            button("Stop") { stopResearch() }
        ).forEach { controls.addView(it, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(3) }) }
        root.addView(controls)

        root.addView(label("वेबसाइट स्क्रीन", 13f, true))
        webView = WebView(this)
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        val scroll = ScrollView(this)
        scroll.addView(queueText)
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(100)))
        setContentView(root)
    }

    private fun numberInput(value: String) = EditText(this).apply {
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        textSize = 16f
        inputType = InputType.TYPE_CLASS_NUMBER
        gravity = Gravity.CENTER
        setBackgroundColor(Color.rgb(24, 38, 60))
    }

    private fun configureWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (state == State.LOADING) {
                    pageTimerStarted = false
                    handler.removeCallbacks(loadTimeoutRunnable)
                    handler.postDelayed(loadTimeoutRunnable, loadTimeoutSeconds * 1000L)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (state == State.LOADING && !pageTimerStarted && index in urls.indices) {
                    pageTimerStarted = true
                    handler.removeCallbacks(loadTimeoutRunnable)
                    statuses[index] = "Running"
                    state = State.RUNNING
                    secondsLeft = secondsPerSite
                    handler.removeCallbacks(tickRunnable)
                    handler.postDelayed(tickRunnable, 1000L)
                    updateUi()
                }
            }

            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true && state == State.LOADING && index in urls.indices) {
                    handler.removeCallbacks(loadTimeoutRunnable)
                    statuses[index] = "Failed"
                    index++
                    loadCurrent()
                }
            }

            override fun onReceivedHttpError(
                view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
                // HTTP error pages are allowed to finish and remain visible; not every 4xx/5xx is a transport failure.
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
                if (state == State.LOADING && index in urls.indices) {
                    this@MainActivity.handler.removeCallbacks(loadTimeoutRunnable)
                    statuses[index] = "Failed"
                    index++
                    loadCurrent()
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme ?: return true
                return scheme != "http" && scheme != "https"
            }
        }
    }

    private fun prepareQueue() {
        val lines = urlsInput.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) { toast("पहले वेबसाइट लिंक डालें।"); return }
        val parsed = mutableListOf<String>()
        for (line in lines) {
            val normalized = if (line.startsWith("http://") || line.startsWith("https://")) line else "https://$line"
            try {
                val uri = URI(normalized)
                if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
                    toast("गलत लिंक: $line"); return
                }
                parsed.add(uri.toASCIIString())
            } catch (_: Exception) { toast("गलत लिंक: $line"); return }
        }
        val secs = secondsInput.text.toString().toIntOrNull()
        val timeout = timeoutInput.text.toString().toIntOrNull()
        if (secs == null || secs !in 5..3600) { toast("वेबसाइट समय 5–3600 सेकंड रखें।"); return }
        if (timeout == null || timeout !in 10..300) { toast("लोडिंग टाइमआउट 10–300 सेकंड रखें।"); return }
        urls = parsed
        secondsPerSite = secs
        loadTimeoutSeconds = timeout
        statuses.clear()
        repeat(urls.size) { statuses.add("Pending") }
        index = 0
        state = State.READY
        updateUi()
        toast("${urls.size} लिंक Queue में तैयार हैं।")
    }

    private fun startResearch() {
        if (state != State.READY || urls.isEmpty()) { toast("पहले लिंक तैयार करें।"); return }
        index = 0
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        loadCurrent()
    }

    private fun loadCurrent() {
        handler.removeCallbacks(tickRunnable)
        handler.removeCallbacks(loadTimeoutRunnable)
        pageTimerStarted = false
        if (index >= urls.size) {
            state = State.DONE
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            updateUi()
            toast("सभी वेबसाइटें पूरी हो गईं।")
            return
        }
        state = State.LOADING
        statuses[index] = "Loading"
        updateUi()
        webView.stopLoading()
        webView.loadUrl(urls[index])
        handler.postDelayed(loadTimeoutRunnable, loadTimeoutSeconds * 1000L)
    }

    private fun pauseResearch() {
        if (state == State.RUNNING) {
            handler.removeCallbacks(tickRunnable)
            state = State.PAUSED
            updateUi()
        } else if (state == State.LOADING) {
            handler.removeCallbacks(loadTimeoutRunnable)
            state = State.PAUSED
            updateUi()
        }
    }

    private fun resumeResearch() {
        if (state != State.PAUSED) return
        if (pageTimerStarted) {
            state = State.RUNNING
            handler.postDelayed(tickRunnable, 1000L)
        } else {
            state = State.LOADING
            handler.postDelayed(loadTimeoutRunnable, loadTimeoutSeconds * 1000L)
        }
        updateUi()
    }

    private fun stopResearch() {
        handler.removeCallbacks(tickRunnable)
        handler.removeCallbacks(loadTimeoutRunnable)
        webView.stopLoading()
        state = State.STOPPED
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        updateUi()
    }

    private fun updateUi() {
        statusText.text = "स्थिति: " + when (state) {
            State.IDLE -> "तैयार नहीं"
            State.READY -> "Queue तैयार"
            State.LOADING -> "वेबसाइट लोड हो रही है"
            State.RUNNING -> "चल रहा है"
            State.PAUSED -> "रुका हुआ"
            State.STOPPED -> "बंद"
            State.DONE -> "सभी पूरे"
        }
        val done = statuses.count { it == "Done" || it == "Failed" }
        progressText.text = "प्रगति: $done / ${urls.size}  |  Done: ${statuses.count { it == "Done" }}  Failed: ${statuses.count { it == "Failed" }}"
        currentText.text = "वर्तमान: " + (urls.getOrNull(index) ?: "—")
        timerText.text = if (state == State.RUNNING) "बाकी समय: ${secondsLeft} सेकंड"
            else if (state == State.LOADING) "लोडिंग टाइमआउट: ${loadTimeoutSeconds} सेकंड"
            else "समय: —"
        queueText.text = urls.mapIndexed { i, url ->
            "${i + 1}. ${statuses.getOrNull(i) ?: "Pending"} — $url"
        }.joinToString("\n")
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tickRunnable)
        handler.removeCallbacks(loadTimeoutRunnable)
        if (::webView.isInitialized) {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }
}
