AUTO RESEARCH — ANDROID SOURCE PROJECT

यह Android Studio project है, compiled APK नहीं।

मुख्य काम:
- कई URL क्रम से लेना
- एक ही Android WebView में अगला URL खोलना
- पेज लोड पूरा होने के बाद टाइमर शुरू करना
- Pause, Resume और Stop
- स्क्रीन चालू रखना ताकि ऐप foreground में रहते हुए timer चलता रहे

महत्वपूर्ण:
1. यह निजी उपयोग के लिए बिना सर्वर/सब्सक्रिप्शन वाला source project है।
2. APK बनाने के लिए Android Studio और Android SDK वाले कंप्यूटर की जरूरत होगी।
3. इस वातावरण में Android SDK उपलब्ध न होने के कारण APK compile नहीं किया गया है।
4. ऐप खुला और foreground में रखें। ऐप बंद या background में जाने पर Android timer को रोक/सीमित कर सकता है।
5. कुछ वेबसाइटें WebView को ब्लॉक कर सकती हैं या सामान्य Chrome से अलग दिख सकती हैं।
6. यह ऐप केवल http/https URLs खोलता है; ads पर क्लिक या engagement metrics बढ़ाने का काम नहीं करता।

Build:
- Android Studio में इस folder को Open करें।
- Gradle Sync पूरा होने दें।
- Build > Build Bundle(s) / APK(s) > Build APK(s)
- APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।
