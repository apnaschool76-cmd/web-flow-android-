WEB FLOW — Android APK source project

This package contains an Android Studio project plus a GitHub Actions workflow
that can build a debug APK in the cloud, so a computer is not required.

APP BEHAVIOR
- Paste one HTTP/HTTPS URL per line.
- Choose visit duration (5 to 3600 seconds).
- Choose page-load timeout (10 to 300 seconds; default 45).
- Opens each URL in one Android WebView.
- Starts visit timer after the page load-complete callback.
- Main-frame load errors / SSL errors / timeout mark that URL Failed and continue.
- Pause, Resume, Stop, and automatic stop after the queue.
- Keeps screen awake while the queue is active.

IMPORTANT LIMITATIONS
- This is source code, not a prebuilt APK.
- Android WebView onPageFinished indicates page loading completion callback, not that every image/script/network request has finished.
- Some websites block or behave differently in WebView. Login, DRM, downloads, popups, external app links, and sites requiring full Chrome may not work.
- Android may still terminate the app under memory/battery pressure. Keep it foreground and screen awake.
- Use for legitimate research and testing only; it does not click ads or create artificial engagement.
- The project enables JavaScript and DOM storage for compatibility with modern sites. Only visit URLs you trust.

BUILD APK USING ONLY YOUR ANDROID PHONE (GitHub Actions)
1. Create/sign in to a GitHub account in your mobile browser.
2. Create a NEW PUBLIC repository named web-flow-android. Public repo is needed for the no-cost standard hosted runner path.
3. Extract this ZIP using your phone's file manager / archive app.
4. Open the extracted AutoResearchAndroid folder. Upload its CONTENTS to the repository root, including the hidden .github folder and .github/workflows/build-apk.yml.
   Important: do not upload the outer AutoResearchAndroid folder as a nested folder; upload the files/folders inside it to repository root.
5. Open repository > Actions. If prompted, enable workflows.
6. Open "Build WEB FLOW APK" and choose "Run workflow" if it did not start automatically after upload.
7. Wait for the workflow to finish successfully.
8. Open the completed run. Under Artifacts, download "WEB-FLOW-debug-APK".
9. Extract the artifact ZIP if needed. Find app-debug.apk and tap it to install.
10. If Android asks, allow your browser/file manager to install unknown apps for this installation, then install. Only install the APK you built from this source.

COST
- GitHub states standard GitHub-hosted runners are free for public repositories. Public source code will be visible to everyone.
- Avoid private repository runner usage if you require strictly zero cost; private repos have quotas and potential overage billing.
- No payment card should be required for the public-repository build path. Check GitHub's current billing screen before enabling any paid feature.
- Artifacts expire after 7 days in this workflow; download promptly.

The workflow uses GitHub Actions, Java 17, Gradle 8.9, Android Gradle Plugin 8.6.1, and uploads the debug APK as an artifact.
